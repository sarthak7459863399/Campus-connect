CampusConnect Student Prototype

FILES TO UPLOAD TO GITHUB REPOSITORY ROOT:
- index.html
- manifest.json
- sw.js
- icon.svg
- README.txt (optional)

IMPORTANT:
- Extract this ZIP before uploading. Do not upload only the ZIP file.
- Keep index.html at the top level of the repository.
- Enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /(root).
- This is a demonstration only. Notice, timetable and bus information is sample data.
- Live GPS tracking, student login, official college integration and real PDF hosting are not connected.
